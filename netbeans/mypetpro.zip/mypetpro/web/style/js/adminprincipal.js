//carga modulos

function cargarModuloEmpleados()
{
    $("#tituloScreen").html("Empleados");
    $("#empleados").addClass("seleccion");
    $("#proveedores").removeClass("seleccion");
    $("#mascotas").removeClass("seleccion");
    $("#clientes").removeClass("seleccion");
    $("#productos").removeClass("seleccion");
    $.ajax
            ({
                url: "modulos/empleados.html",
                context: document.body
            })
            .done(function (data)
            {
                $("#divContenido").html(data);
                mostrarTablaEmpleados();
            });
            
            
}

function cargarModuloClientes()
{
    $("#tituloScreen").html("Clientes");
    $("#empleados").removeClass("seleccion");
    $("#proveedores").removeClass("seleccion");
    $("#mascotas").removeClass("seleccion");
    $("#clientes").addClass("seleccion");
    $("#productos").removeClass("seleccion");
    $.ajax
            ({
                url: "modulos/clientes.html",
                context: document.body
            })
            .done(function (data)
            {
                $("#divContenido").html(data);
                mostrarTablaCliente();
            });
}

function cargarModuloProveedores()
{
    $("#tituloScreen").html("Proveedores");
    $("#empleados").removeClass("seleccion");
    $("#proveedores").addClass("seleccion");
    $("#mascotas").removeClass("seleccion");
    $("#clientes").removeClass("seleccion");
    $("#productos").removeClass("seleccion");
    $.ajax
            ({
                url: "modulos/proveedores.html",
                context: document.body
            })
            .done(function (data)
            {
                $("#divContenido").html(data);
                mostrarTablaProveedores();
            });
}

function cargarModuloMascotas()
{
    $("#tituloScreen").html("Mascotas");
    $("#empleados").removeClass("seleccion");
    $("#proveedores").removeClass("seleccion");
    $("#mascotas").addClass("seleccion");
    $("#clientes").removeClass("seleccion");
    $("#productos").removeClass("seleccion");
    $.ajax
            ({
                url: "modulos/mascotas.html",
                context: document.body
            })
            .done(function (data)
            {
                $("#divContenido").html(data);
                 mostrarTablaMascotas();
            });
}

function cargarModuloMercancia()
{
    $("#tituloScreen").html("Mercancia");
    $("#empleados").removeClass("seleccion");
    $("#proveedores").removeClass("seleccion");
    $("#mascotas").removeClass("seleccion");
    $("#clientes").removeClass("seleccion");
    $("#productos").addClass("seleccion");
    $("#divContenido").removeAttr("style");
    $.ajax
            ({
                url: "modulos/mercancia.html",
                context: document.body
            })
            .done(function (data)
            {
               
                $("#divContenido").html(data);
                mostrarTablaMercancia();                
             
            });
}
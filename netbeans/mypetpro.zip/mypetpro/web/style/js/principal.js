$(document).ready(function () {
    $("#btnLogin").click(function () {
        var email = document.getElementById("txtEmail").value;
        var password = document.getElementById("txtPassword").value;
        if (email === "negro" && password === "negro") {
            window.location.href = 'inicio.html';
        } else {
            if (email === "admin" && password === "admin") {
                window.location.href = 'admin.html';
            } else {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'Nombre de usuario/contraseña incorrecta!'
                });
            }
        }
    });
});

//carga productos
function cargarModuloProductos()
{
    $.ajax
            ({
                url: "mercancia.html",
                context: document.body
            })
            .done(function (data)
            {
                $("#divContenido").html(data);
            });
}

function cargarModuloAnimales()
{
    $.ajax
            ({
                url: "animal.html",
                context: document.body
            })
            .done(function (data)
            {
                $("#divContenido").html(data);
            });
}

//carga conocenos
function cargarModuloConocenos()
{
    $.ajax
            ({
                url: "conocenos.html",
                context: document.body
            })
            .done(function (data)
            {
                $("#divContenido").html(data);
            });
}
var clientes =
        [
            {
                numero_cliente: 1,
                fecha_nac: "1995-02-15",
                nombre: "Juan",
                appellido_pat: "Perez",
                appellido_mat: "Gonzales",
                telefono: 4771234567,
                correo: "juanitoperez@gmail.com",
                contrasenia: "jp123",
                estatus: true
            },
            {
                numero_cliente: 2,
                fecha_nac: "1995-02-15",
                nombre: "Juan",
                appellido_pat: "Perez",
                appellido_mat: "Gonzales",
                telefono: 4771234567,
                correo: "juanitoperez@gmail.com",
                contrasenia: "jp123",
                estatus: true
            },
            {
                numero_cliente: 3,
                fecha_nac: "1995-02-15",
                nombre: "Juan",
                appellido_pat: "Perez",
                appellido_mat: "Gonzales",
                telefono: 4771234567,
                correo: "juanitoperez@gmail.com",
                contrasenia: "jp123",
                estatus: true
            },
            {
                numero_cliente: 4,
                fecha_nac: "1995-02-15",
                nombre: "Juan",
                appellido_pat: "Perez",
                appellido_mat: "Gonzales",
                telefono: 4771234567,
                correo: "juanitoperez@gmail.com",
                contrasenia: "jp123",
                estatus: true
            },
            {
                numero_cliente: 5,
                fecha_nac: "1995-02-15",
                nombre: "Juan",
                appellido_pat: "Perez",
                appellido_mat: "Gonzales",
                telefono: 4771234567,
                correo: "juanitoperez@gmail.com",
                contrasenia: "jp123",
                estatus: true
            }
        ];

function mostrarTablaCliente()
{
    $("#btnAdd").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < clientes.length; i++)
    {
        if (clientes[i].estatus === true) {
            contenido +=
                    '<tr id="empleado' + i + '">' +
                    '<td id="idEmpleado' + i + '">' + clientes[i].numero_cliente + '</td>' +
                    '<td id="nombre' + i + '">' + clientes[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + clientes[i].appellido_pat + '</td>' +
                    '<td id="aMaterno' + i + '">' + clientes[i].appellido_mat + '</td>' +
                    '<td id="fechaNac' + i + '">' + clientes[i].fecha_nac + '</td>' +
                    '<td id="correo' + i + '">' +
                    '<a href="mailto:' + clientes[i].correo + '">' + clientes[i].correo + '</a>' +
                    '</td>' +
                    '<td id="telefono' + i + '">' + clientes[i].telefono + '</td>' +
                    '<td id="estatus' + i + '">' + (clientes[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editCliente(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteCliente(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        } else {
            contenido +=
                    '<tr id="empleado' + i + '">' +
                    '<td id="idEmpleado' + i + '">' + clientes[i].numero_cliente + '</td>' +
                    '<td id="nombre' + i + '">' + clientes[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + clientes[i].appellido_pat + '</td>' +
                    '<td id="aMaterno' + i + '">' + clientes[i].appellido_mat + '</td>' +
                    '<td id="fechaNac' + i + '">' + clientes[i].fecha_nac + '</td>' +
                    '<td id="correo' + i + '">' +
                    '<a href="mailto:' + clientes[i].correo + '">' + clientes[i].correo + '</a>' +
                    '</td>' +
                    '<td id="telefono' + i + '">' + clientes[i].telefono + '</td>' +
                    '<td id="estatus' + i + '">' + (clientes[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editCliente(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-success" onclick="activarCliente(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        }
    }
    $("#tbodyclientes").html(contenido);
}

function mostraralagregaroelicli(){
    
     $("#btnAddProv").prop("disabled", false);
    var contenido = '';
   for (var i = 0; i < clientes.length; i++)
    {
        if (clientes[i].estatus === true) {
            contenido +=
                    '<tr id="empleado' + i + '">' +
                    '<td id="idEmpleado' + i + '">' + clientes[i].numero_cliente + '</td>' +
                    '<td id="nombre' + i + '">' + clientes[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + clientes[i].appellido_pat + '</td>' +
                    '<td id="aMaterno' + i + '">' + clientes[i].appellido_mat + '</td>' +
                    '<td id="fechaNac' + i + '">' + clientes[i].fecha_nac + '</td>' +
                    '<td id="correo' + i + '">' +
                    '<a href="mailto:' + clientes[i].correo + '">' + clientes[i].correo + '</a>' +
                    '</td>' +
                    '<td id="telefono' + i + '">' + clientes[i].telefono + '</td>' +
                    '<td id="estatus' + i + '">' + (clientes[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editCliente(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteCliente(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
             }
    $("#tbodyclientes").html(contenido);
    
    
}
}

function filtrarCli() {
    var optFiltro = parseInt($("#selectFiltro").val());
    var contenido = '';
    switch (optFiltro) {
        case 0:
            mostrarTablaCliente();
        break;
        case 1:
            for (var i = 0; i < clientes.length; i++)
            {
                if (clientes[i].estatus === false) {
                    contenido +=
                            '<tr id="empleado' + i + '">' +
                            '<td id="idEmpleado' + i + '">' + clientes[i].numero_cliente + '</td>' +
                            '<td id="nombre' + i + '">' + clientes[i].nombre + '</td>' +
                            '<td id="aPaterno' + i + '">' + clientes[i].appellido_pat + '</td>' +
                            '<td id="aMaterno' + i + '">' + clientes[i].appellido_mat + '</td>' +
                            '<td id="fechaNac' + i + '">' + clientes[i].fecha_nac + '</td>' +
                            '<td id="correo' + i + '">' +
                            '<a href="mailto:' + clientes[i].correo + '">' + clientes[i].correo + '</a>' +
                            '</td>' +
                            '<td id="telefono' + i + '">' + clientes[i].telefono + '</td>' +
                            '<td id="estatus' + i + '">' + (clientes[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editCliente(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-success" onclick="activarCliente(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyclientes").html(contenido);
            break;
        case 2:
            for (var i = 0; i < clientes.length; i++)
            {
                if (clientes[i].estatus === true) {
                    contenido +=
                            '<tr id="empleado' + i + '">' +
                            '<td id="idEmpleado' + i + '">' + clientes[i].numero_cliente + '</td>' +
                            '<td id="nombre' + i + '">' + clientes[i].nombre + '</td>' +
                            '<td id="aPaterno' + i + '">' + clientes[i].appellido_pat + '</td>' +
                            '<td id="aMaterno' + i + '">' + clientes[i].appellido_mat + '</td>' +
                            '<td id="fechaNac' + i + '">' + clientes[i].fecha_nac + '</td>' +
                            '<td id="correo' + i + '">' +
                            '<a href="mailto:' + clientes[i].correo + '">' + clientes[i].correo + '</a>' +
                            '</td>' +
                            '<td id="telefono' + i + '">' + clientes[i].telefono + '</td>' +
                            '<td id="estatus' + i + '">' + (clientes[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editCliente(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-danger"  onclick="deleteCliente(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyclientes").html(contenido);
            break;
    }
}

function activarCliente(pos) {
    if (clientes[pos].estatus === false) {
        clientes[pos].estatus = true;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Cliente activado exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' este cliente ya esta agregado!'
        });
        mostrarTablaCliente();
    }
    filtrarCli();
}

$("#btnAdd").click(function ()
{
    ocultarContrasenia();
    $("#exampleModalLabel").addClass("text-success");
    $("#exampleModalLabel").removeClass("text-warning");
    $("#exampleModalLabel").html("Agregar Cliente");
    $("#btnEditCliente").hide();
    $("#btnAddCliente").show();
    $("#txtnumero_cliente").val(clientes.length + 1);
    $("#txtnombre").val(null);
    $("#txtappellido_pat").val(null);
    $("#txtappellido_mat").val(null);
    $("#txtFecha_nac").val(null);
    $("#txtcorreo").val(null);
    $("#txtContrasenia").val(null);
    $("#txttelefono").val(null);
    $("#chkClienteActivo").prop("checked", true);
    $("#chkClienteActivo").prop("disabled", true);
});

function confirmarNuevoCliente()
{
    clientes.push
            (
                    {
                        numero_cliente: $("#txtnumero_cliente").val(),
                        nombre: $("#txtnombre").val(),
                        fecha_nac: $("#txtappellido_pat").val(),
                        appellido_pat: $("#txtappellido_mat").val(),
                        appellido_mat: $("#txtFecha_nac").val(),
                        telefono: $("#txtcorreo").val(),
                        correo: $("#txttelefono").val(),
                        contrasenia: $("#txtContrasenia").val(),
                        estatus: true
                    }
            );
    alerta();
   mostraralagregaroelicli();
}

function editCliente(pos)
{
    ocultarContrasenia();
    $("#exampleModalLabel").html("Editar Cliente");
    $("#exampleModalLabel").removeClass("text-success");
    $("#exampleModalLabel").addClass("text-warning");
    $("#btnEditCliente").show();
    $("#btnAddCliente").hide();
    $("#txtnumero_cliente").val(clientes[pos].numero_cliente);
    $("#txtnombre").val(clientes[pos].nombre);
    $("#txtappellido_pat").val(clientes[pos].appellido_pat);
    $("#txtappellido_mat").val(clientes[pos].appellido_mat);
    $("#txtFecha_nac").val(clientes[pos].fecha_nac);
    $("#txtcorreo").val(clientes[pos].correo);
    $("#txtContrasenia").val(clientes[pos].contrasenia);
    $("#txttelefono").val(clientes[pos].telefono);
    $("#chkClienteActivo").prop("disabled", false);
    var estatus = clientes[pos].estatus;
    if (estatus === true) {
        chkClienteActivo.checked = true;

    } else {
        chkClienteActivo.checked = false;
    }

    $("#contDinamico").html
            (
                    '<button id="btnEditCliente" type="button" class="btn btn-primary" data-dismiss="modal" onclick="guardarEditCliente(' + pos + ');">Guardar</button>'
                    );
}

function guardarEditCliente(pos)
{
    alerta();
    clientes[pos].numero_cliente = $("#txtnumero_cliente").val();
    clientes[pos].nombre = $("#txtnombre").val();
    clientes[pos].appellido_pat = $("#txtappellido_pat").val();
    clientes[pos].appellido_mat = $("#txtappellido_mat").val();
    clientes[pos].fecha_nac = $("#txtFecha_nac").val();
    clientes[pos].correo = $("#txtcorreo").val();
    clientes[pos].contrasenia = $("#txtContrasenia").val();
    clientes[pos].telefono = $("#txttelefono").val();
    $("#chkClienteActivo").prop("disabled", false);
    if (chkClienteActivo.checked === true) {
        clientes[pos].estatus = true;

    } else {
        clientes[pos].estatus = false;
    }
    mostrarTablaCliente();
}

function alerta()
{
    Swal.fire({
        icon: 'success',
        title: 'Hecho',
        text: 'Guardado Exitosamente!'
    });
}

function deleteCliente(pos)
{
    if (clientes[pos].estatus === true) {
        clientes[pos].estatus = false;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Cliente eliminado de forma logica exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' este cliente ya esta eliminado logicamente!'
        });
        mostraralagregaroelicli();
    }
 
}

function mostrarContrasenia()
{
    $("#txtContrasenia").prop("type", "text");
    $("#mostrarPassword").hide();
    $("#ocultarPassword").show();
}

function ocultarContrasenia()
{
    $("#txtContrasenia").prop("type", "password");
    $("#mostrarPassword").show();
    $("#ocultarPassword").hide();
}
var empleados =
        [
            {
                idEmpleado: 1,
                tipoEmpleado: "empleado",
                nombre: "Juan",
                aPaterno: "Perez",
                aMaterno: "Ibarra",
                fechaNac: "1995-02-15",
                correo: "juanitoperez@gmail.com",
                contrasenia: "jp123",
                telefono: 4771234567,
                calle: "Camelinas",
                numero: 777,
                colonia: "Chapalita",
                CP: 37200,
                estatus: true
            },
            {
                idEmpleado: 2,
                tipoEmpleado: "empleado",
                nombre: "Jorge",
                aPaterno: "Zapata",
                aMaterno: "Lion",
                fechaNac: "1984-09-29",
                correo: "jorgezapata@gmail.com",
                contrasenia: "jz123",
                telefono: 4777654321,
                calle: "Rancho Camelot",
                numero: 543,
                colonia: "Residencial Las Arboledas",
                CP: 37666,
                estatus: true
            },
            {
                idEmpleado: 3,
                tipoEmpleado: "empleado",
                nombre: "Jefferson",
                aPaterno: "Gutierritos",
                aMaterno: "Yakitori",
                fechaNac: "1995-02-15",
                correo: "jeffersonguti@gmail.com",
                contrasenia: "jg123",
                telefono: 4776584316,
                calle: "Leon Uñas",
                numero: 810,
                colonia: "80 ranchos",
                CP: 37973,
                estatus: true
            },
            {
                idEmpleado: 4,
                tipoEmpleado: "administrador",
                nombre: "Alexander",
                aPaterno: "Turner",
                aMaterno: "Sanchez",
                fechaNac: "1984-08-29",
                correo: "AlexT@gmail.com",
                contrasenia: "ts123",
                telefono: 47772023639,
                calle: "chifiel",
                numero: 2711,
                colonia: "liondres",
                CP: 37500,
                estatus: true
            },
            {
                idEmpleado: 5,
                tipoEmpleado: "empleado",
                nombre: "Julian",
                aPaterno: "Casablancas",
                aMaterno: "Stroke",
                fechaNac: "1989-10-19",
                correo: "lostrazos@gmail.com",
                contrasenia: "cs123",
                telefono: 47772923668,
                calle: "new york",
                numero: 777,
                colonia: "10 de mayami",
                CP: 37330,
                estatus: true
            }
        ];

function mostrarTablaEmpleados()
{
    $("#btnAdd").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < empleados.length; i++)
    {
        if (empleados[i].estatus === true) {
            contenido +=
                    '<tr id="empleado' + i + '">' +
                    '<td id="idEmpleado' + i + '">' + empleados[i].idEmpleado + '</td>' +
                    '<td id="tipoEmpleado' + i + '">' + empleados[i].tipoEmpleado + '</td>' +
                    '<td id="nombre' + i + '">' + empleados[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + empleados[i].aPaterno + '</td>' +
                    '<td id="aMaterno' + i + '">' + empleados[i].aMaterno + '</td>' +
                    '<td id="fechaNac' + i + '">' + empleados[i].fechaNac + '</td>' +
                    '<td id="correo' + i + '">' +
                    '<a href="mailto:' + empleados[i].correo + '">' + empleados[i].correo + '</a>' +
                    '</td>' +
                    '<td id="telefono' + i + '">' + empleados[i].telefono + '</td>' +
                    '<td id="direccion' + i + '">' + empleados[i].calle + " #" + empleados[i].numero + ", " + empleados[i].colonia + ". " + empleados[i].CP + '</td>' +
                    '<td id="estatus' + i + '">' + (empleados[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editEmpleado(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteEmpleado(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        } else {
            contenido +=
                    '<tr id="empleado' + i + '">' +
                    '<td id="idEmpleado' + i + '">' + empleados[i].idEmpleado + '</td>' +
                    '<td id="tipoEmpleado' + i + '">' + empleados[i].tipoEmpleado + '</td>' +
                    '<td id="nombre' + i + '">' + empleados[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + empleados[i].aPaterno + '</td>' +
                    '<td id="aMaterno' + i + '">' + empleados[i].aMaterno + '</td>' +
                    '<td id="fechaNac' + i + '">' + empleados[i].fechaNac + '</td>' +
                    '<td id="correo' + i + '">' +
                    '<a href="mailto:' + empleados[i].correo + '">' + empleados[i].correo + '</a>' +
                    '</td>' +
                    '<td id="telefono' + i + '">' + empleados[i].telefono + '</td>' +
                    '<td id="direccion' + i + '">' + empleados[i].calle + " #" + empleados[i].numero + ", " + empleados[i].colonia + ". " + empleados[i].CP + '</td>' +
                    '<td id="estatus' + i + '">' + (empleados[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editEmpleado(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-success" onclick="activarEmpleado(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        }
    }
    $("#tbodyEmpleados").html(contenido);
}

function mostraralagregaroeliemp(){
    
     $("#btnAddProv").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < empleados.length; i++)
    {
       if (empleados[i].estatus === true) {
            contenido +=
                    '<tr id="empleado' + i + '">' +
                    '<td id="idEmpleado' + i + '">' + empleados[i].idEmpleado + '</td>' +
                    '<td id="tipoEmpleado' + i + '">' + empleados[i].tipoEmpleado + '</td>' +
                    '<td id="nombre' + i + '">' + empleados[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + empleados[i].aPaterno + '</td>' +
                    '<td id="aMaterno' + i + '">' + empleados[i].aMaterno + '</td>' +
                    '<td id="fechaNac' + i + '">' + empleados[i].fechaNac + '</td>' +
                    '<td id="correo' + i + '">' +
                    '<a href="mailto:' + empleados[i].correo + '">' + empleados[i].correo + '</a>' +
                    '</td>' +
                    '<td id="telefono' + i + '">' + empleados[i].telefono + '</td>' +
                    '<td id="direccion' + i + '">' + empleados[i].calle + " #" + empleados[i].numero + ", " + empleados[i].colonia + ". " + empleados[i].CP + '</td>' +
                    '<td id="estatus' + i + '">' + (empleados[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editEmpleado(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteEmpleado(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
             }
    $("#tbodyEmpleados").html(contenido);
    
    
}
}

function filtrarEmp() {
    var optFiltro = parseInt($("#selectFiltro").val());
    var contenido = '';
    switch (optFiltro) {
        case 0:
            mostrarTablaEmpleados();
        break;
        case 1:
            for (var i = 0; i < empleados.length; i++)
            {
                if (empleados[i].estatus === false) {
                    contenido +=
                            '<tr id="empleado' + i + '">' +
                            '<td id="idEmpleado' + i + '">' + empleados[i].idEmpleado + '</td>' +
                            '<td id="tipoEmpleado' + i + '">' + empleados[i].tipoEmpleado + '</td>' +
                            '<td id="nombre' + i + '">' + empleados[i].nombre + '</td>' +
                            '<td id="aPaterno' + i + '">' + empleados[i].aPaterno + '</td>' +
                            '<td id="aMaterno' + i + '">' + empleados[i].aMaterno + '</td>' +
                            '<td id="fechaNac' + i + '">' + empleados[i].fechaNac + '</td>' +
                            '<td id="correo' + i + '">' +
                            '<a href="mailto:' + empleados[i].correo + '">' + empleados[i].correo + '</a>' +
                            '</td>' +
                            '<td id="telefono' + i + '">' + empleados[i].telefono + '</td>' +
                            '<td id="direccion' + i + '">' + empleados[i].calle + " #" + empleados[i].numero + ", " + empleados[i].colonia + ". " + empleados[i].CP + '</td>' +
                            '<td id="estatus' + i + '">' + (empleados[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editEmpleado(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-success" onclick="activarEmpleado(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyEmpleados").html(contenido);
            break;
        case 2:
            for (var i = 0; i < empleados.length; i++)
            {
                if (empleados[i].estatus === true) {
                    contenido +=
                            '<tr id="empleado' + i + '">' +
                            '<td id="idEmpleado' + i + '">' + empleados[i].idEmpleado + '</td>' +
                            '<td id="tipoEmpleado' + i + '">' + empleados[i].tipoEmpleado + '</td>' +
                            '<td id="nombre' + i + '">' + empleados[i].nombre + '</td>' +
                            '<td id="aPaterno' + i + '">' + empleados[i].aPaterno + '</td>' +
                            '<td id="aMaterno' + i + '">' + empleados[i].aMaterno + '</td>' +
                            '<td id="fechaNac' + i + '">' + empleados[i].fechaNac + '</td>' +
                            '<td id="correo' + i + '">' +
                            '<a href="mailto:' + empleados[i].correo + '">' + empleados[i].correo + '</a>' +
                            '</td>' +
                            '<td id="telefono' + i + '">' + empleados[i].telefono + '</td>' +
                            '<td id="direccion' + i + '">' + empleados[i].calle + " #" + empleados[i].numero + ", " + empleados[i].colonia + ". " + empleados[i].CP + '</td>' +
                            '<td id="estatus' + i + '">' + (empleados[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editEmpleado(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-danger"  onclick="deleteEmpleado(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyEmpleados").html(contenido);
            break;
    }

}

function activarEmpleado(pos) {
    if (empleados[pos].estatus === false) {
        empleados[pos].estatus = true;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Empleado activado exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' este empleado ya esta agregado!'
        });
        mostrarTablaEmpleados();
    }
    filtrarEmp();
}

function deleteEmpleado(pos)
{
    if (empleados[pos].estatus === true) {
        empleados[pos].estatus = false;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Empleado eliminado de forma logica exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' este empleado ya esta eliminado logicamente!'
        });
       mostraralagregaroeliemp();
    }
   
}

$("#btnAdd").click(function ()
{
    $("#exampleModalLabel").addClass("text-success");
    $("#exampleModalLabel").removeClass("text-warning");
    $("#exampleModalLabel").html("Agregar Empleado");
    $("#btnEditEmpleado").hide();
    $("#btnAddEmpleado").show();
    ocultarContrasenia();
    $("#txtIdEmpleado").val(empleados.length + 1);
    $("#txtTipoEmpleado").val(null);
    $("#txtNombre").val(null);
    $("#txtApellidoP").val(null);
    $("#txtApellidoM").val(null);
    $("#txtFechaNac").val(null);
    $("#txtCorreo").val(null);
    $("#txtContrasenia").val(null);
    $("#txtTel").val(null);
    $("#txtCalle").val(null);
    $("#txtNumero").val(null);
    $("#txtColonia").val(null);
    $("#txtCP").val(null);
    $("#chkEmpleadoActivo").prop("checked", true);
    $("#chkEmpleadoActivo").prop("disabled", true);
});

function editEmpleado(pos)
{
    ocultarContrasenia();
    $("#exampleModalLabel").html("Editar Empleado");
    $("#exampleModalLabel").removeClass("text-success");
    $("#exampleModalLabel").addClass("text-warning");
    $("#btnEditEmpleado").show();
    $("#btnAddEmpleado").hide();
    $("#txtIdEmpleado").val(empleados[pos].idEmpleado);
    $("#txtTipoEmpleado").val(empleados[pos].tipoEmpleado);
    $("#txtNombre").val(empleados[pos].nombre);
    $("#txtApellidoP").val(empleados[pos].aPaterno);
    $("#txtApellidoM").val(empleados[pos].aMaterno);
    $("#txtFechaNac").val(empleados[pos].fechaNac);
    $("#txtCorreo").val(empleados[pos].correo);
    $("#txtContrasenia").val(empleados[pos].contrasenia);
    $("#txtTel").val(empleados[pos].telefono);
    $("#txtCalle").val(empleados[pos].calle);
    $("#txtNumero").val(empleados[pos].numero);
    $("#txtColonia").val(empleados[pos].colonia);
    $("#txtCP").val(empleados[pos].CP);
    $("#chkEmpleadoActivo").prop("disabled", false);
    $("#chkEmpleadoActivo").val(empleados[pos].estatus);
    if (empleados[pos].estatus === true) {
        chkEmpleadoActivo.checked = true;
    } else {
        chkEmpleadoActivo.checked = false;
    }
    $("#contDinamico").html
            (
                    '<button id="btnEditEmpleado" type="button" class="btn btn-primary" data-dismiss="modal" onclick="guardarEditEmpleado(' + pos + ');">Guardar</button>'
                    );
}

function guardarEditEmpleado(pos)
{
    alerta();
    empleados[pos].idEmpleado = $("#txtIdEmpleado").val();
    empleados[pos].tipoEmpleado = $("#txtTipoEmpleado").val();
    empleados[pos].nombre = $("#txtNombre").val();
    empleados[pos].aPaterno = $("#txtApellidoP").val();
    empleados[pos].aMaterno = $("#txtApellidoM").val();
    empleados[pos].fechaNac = $("#txtFechaNac").val();
    empleados[pos].correo = $("#txtCorreo").val();
    empleados[pos].contrasenia = $("#txtContrasenia").val();
    empleados[pos].telefono = $("#txtTel").val();
    empleados[pos].calle = $("#txtCalle").val();
    empleados[pos].numero = $("#txtNumero").val();
    empleados[pos].colonia = $("#txtColonia").val();
    empleados[pos].CP = $("#txtCP").val();
    if (chkEmpleadoActivo.checked === true) {
        empleados[pos].estatus = true;
    } else {
        empleados[pos].estatus = false;
    }
    mostrarTablaEmpleados();
}

function alerta()
{
    Swal.fire({
        icon: 'success',
        title: 'Hecho',
        text: 'Guardado Exitosamente!'
    });
}

function confirmarNuevoEmpleado()
{
    empleados.push
            (
                    {
                        idEmpleado: $("#txtIdEmpleado").val(),
                        tipoEmpleado: $("#txtTipoEmpleado").val(),
                        nombre: $("#txtNombre").val(),
                        aPaterno: $("#txtApellidoP").val(),
                        aMaterno: $("#txtApellidoM").val(),
                        fechaNac: $("#txtFechaNac").val(),
                        correo: $("#txtCorreo").val(),
                        contrasenia: $("#txtContrasenia").val(),
                        telefono: $("#txtTel").val(),
                        calle: $("#txtCalle").val(),
                        numero: $("#txtNumero").val(),
                        colonia: $("#txtColonia").val(),
                        CP: $("#txtCP").val(),
                        estatus: true
                    }
            );
    alerta();
   mostraralagregaroeliemp();
}

function mostrarContrasenia()
{
    $("#txtContrasenia").prop("type", "text");
    $("#mostrarPassword").hide();
    $("#ocultarPassword").show();
}

function ocultarContrasenia()
{
    $("#txtContrasenia").prop("type", "password");
    $("#mostrarPassword").show();
    $("#ocultarPassword").hide();
}
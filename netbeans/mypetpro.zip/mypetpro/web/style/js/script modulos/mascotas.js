var mascotas =
        [
            {
                codigoInterno: "PA-1",
                codigo: Math.floor(Math.random() * 100000000000),
                nombre: "Benito el perro",
                raza: "Pug",
                especie: "Perro",
                fechaNac: "2020-04-15",
                fechaLlegada: "2020-06-15",
                precio: 1500,
                existencias: 1,
                estatus: true
            },
            {
                codigoInterno: "PA-2",
                codigo: Math.floor(Math.random() * 100000000000),
                nombre: "Jake el perro",
                raza: "Pitbull",
                especie: "Perro",
                fechaNac: "2020-05-13",
                fechaLlegada: "2020-06-13",
                precio: 1750,
                existencias: 1,
                estatus: true
            },
            {
                codigoInterno: "PA-3",
                codigo: Math.floor(Math.random() * 100000000000),
                nombre: "Ulises el gato",
                raza: "British Shorthair",
                especie: "Gato",
                fechaNac: "2020-05-07",
                fechaLlegada: "2020-06-24",
                precio: 2000,
                existencias: 1,
                estatus: true
            }
        ];

function mostrarTablaMascotas()
{
    $("#btnAdd").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < mascotas.length; i++)
    {
        if (mascotas[i].estatus === true) {
            contenido +=
                    '<tr id="mascota' + i + '">' +
                    '<td>' + mascotas[i].codigoInterno + '</td>' +
                    '<td>' + mascotas[i].codigo + '</td>' +
                    '<td>' + mascotas[i].nombre + '</td>' +
                    '<td>' + mascotas[i].raza + '</td>' +
                    '<td>' + mascotas[i].especie + '</td>' +
                    '<td>' + mascotas[i].fechaNac + '</td>' +
                    '<td>' + mascotas[i].fechaLlegada + '</td>' +
                    '<td>' + '$' + mascotas[i].precio + '</td>' +
                    '<td>' + '$' + (mascotas[i].precio * 2) + '</td>' +
                    '<td>' + mascotas[i].existencias + '</td>' +
                    '<td>' + (mascotas[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editMascota(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteMascota(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        } else {
            contenido +=
                    '<tr id="mascota' + i + '">' +
                    '<td>' + mascotas[i].codigoInterno + '</td>' +
                    '<td>' + mascotas[i].codigo + '</td>' +
                    '<td>' + mascotas[i].nombre + '</td>' +
                    '<td>' + mascotas[i].raza + '</td>' +
                    '<td>' + mascotas[i].especie + '</td>' +
                    '<td>' + mascotas[i].fechaNac + '</td>' +
                    '<td>' + mascotas[i].fechaLlegada + '</td>' +
                    '<td>' + '$' + mascotas[i].precio + '</td>' +
                    '<td>' + '$' + (mascotas[i].precio * 2) + '</td>' +
                    '<td>' + mascotas[i].existencias + '</td>' +
                    '<td>' + (mascotas[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editMascota(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-success" onclick="activarMascota(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        }
    }
    $("#tbodyMascotas").html(contenido);
}

function mostraralagregaroelimas(){
    
     $("#btnAddProv").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < mascotas.length; i++)
    {
      if (mascotas[i].estatus === true) {
            contenido +=
                    '<tr id="mascota' + i + '">' +
                    '<td>' + mascotas[i].codigoInterno + '</td>' +
                    '<td>' + mascotas[i].codigo + '</td>' +
                    '<td>' + mascotas[i].nombre + '</td>' +
                    '<td>' + mascotas[i].raza + '</td>' +
                    '<td>' + mascotas[i].especie + '</td>' +
                    '<td>' + mascotas[i].fechaNac + '</td>' +
                    '<td>' + mascotas[i].fechaLlegada + '</td>' +
                    '<td>' + '$' + mascotas[i].precio + '</td>' +
                    '<td>' + '$' + (mascotas[i].precio * 2) + '</td>' +
                    '<td>' + mascotas[i].existencias + '</td>' +
                    '<td>' + (mascotas[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editMascota(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteMascota(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
             }
    $("#tbodyMascotas").html(contenido);
    
    
}
}

function filtrarMasc() {
    var optFiltro = parseInt($("#selectFiltro").val());
    var contenido = '';
    switch (optFiltro) {
        case 0:
            mostrarTablaMascotas();
            break;
        case 1:
            for (var i = 0; i < mascotas.length; i++)
            {
                if (mascotas[i].estatus === false) {
                    contenido +=
                            '<tr id="mascota' + i + '">' +
                            '<td>' + mascotas[i].codigoInterno + '</td>' +
                            '<td>' + mascotas[i].codigo + '</td>' +
                            '<td>' + mascotas[i].nombre + '</td>' +
                            '<td>' + mascotas[i].raza + '</td>' +
                            '<td>' + mascotas[i].especie + '</td>' +
                            '<td>' + mascotas[i].fechaNac + '</td>' +
                            '<td>' + mascotas[i].fechaLlegada + '</td>' +
                            '<td>' + '$' + mascotas[i].precio + '</td>' +
                            '<td>' + '$' + (mascotas[i].precio * 2) + '</td>' +
                            '<td>' + mascotas[i].existencias + '</td>' +
                            '<td>' + (mascotas[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editMascota(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-success" onclick="activarMascota(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyMascotas").html(contenido);
            break;
        case 2:
            for (var i = 0; i < mascotas.length; i++)
            {
                if (mascotas[i].estatus === true) {
                    contenido +=
                            '<tr id="mascota' + i + '">' +
                            '<td>' + mascotas[i].codigoInterno + '</td>' +
                            '<td>' + mascotas[i].codigo + '</td>' +
                            '<td>' + mascotas[i].nombre + '</td>' +
                            '<td>' + mascotas[i].raza + '</td>' +
                            '<td>' + mascotas[i].especie + '</td>' +
                            '<td>' + mascotas[i].fechaNac + '</td>' +
                            '<td>' + mascotas[i].fechaLlegada + '</td>' +
                            '<td>' + '$' + mascotas[i].precio + '</td>' +
                            '<td>' + '$' + (mascotas[i].precio * 2) + '</td>' +
                            '<td>' + mascotas[i].existencias + '</td>' +
                            '<td>' + (mascotas[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editMascota(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-danger"  onclick="deleteMascota(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyMascotas").html(contenido);
            break;
    }
}

function activarMascota(pos) {
    if (mascotas[pos].estatus === false) {
        mascotas[pos].estatus = true;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Mascota activada exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' esta mascota ya esta activada!'
        });
        mostrarTablaMascotas();
    }
    filtrarMasc();
}

function deleteMascota(pos)
{
    if (mascotas[pos].estatus === true) {
        mascotas[pos].estatus = false;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Mascota eliminada de forma logica exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' esta mascota ya esta eliminado logicamente!'
        });
       mostraralagregaroelimas();
    }
    filtrarMasc();
}

$("#btnAdd").click(function ()
{
    $("#exampleModalLabel").addClass("text-success");
    $("#exampleModalLabel").removeClass("text-warning");
    $("#exampleModalLabel").html("Agregar Mascota");
    $("#btnEditMascota").hide();
    $("#btnAddMascota").show();
    $("#txtCodigoInterno").prop("disabled", true);
    $("#txtCodigo").prop("disabled", true);
    $("#txtCodigoInterno").val("PA-" + (mascotas.length + 1));
    $("#txtCodigo").val(Math.floor(Math.random() * 100000000000));
    $("#txtNombre").val(null);
    $("#txtRaza").val(null);
    $("#txtEspecie").val(null);
    $("#txtFechaNac").val(null);
    $("#txtFechaLlegada").val(null);
    $("#txtPrecioCompra").val(null);
    $("#txtExistencias").val(null);
    $("#chkMascotaActiva").prop("checked", true);
    $("#chkMascotaActiva").prop("disabled", true);
});

function confirmarNuevaMascota()
{
    mascotas.push
            (
                    {
                        codigoInterno: $("#txtCodigoInterno").val(),
                        codigo: $("#txtCodigo").val(),
                        nombre: $("#txtNombre").val(),
                        raza: $("#txtRaza").val(),
                        especie: $("#txtEspecie").val(),
                        fechaNac: $("#txtFechaNac").val(),
                        fechaLlegada: $("#txtFechaLlegada").val(),
                        precio: $("#txtPrecioCompra").val(),
                        existencias: $("#txtExistencias").val(),
                        estatus: true
                    }
            );
    alerta();
   mostraralagregaroelimas();
}

function editMascota(pos)
{
    $("#exampleModalLabel").html("Editar Mascota");
    $("#exampleModalLabel").removeClass("text-success");
    $("#exampleModalLabel").addClass("text-warning");
    $("#btnEditMascota").show();
    $("#btnAddMascota").hide();
    $("#txtCodigoInterno").prop("disabled", true);
    $("#txtCodigo").prop("disabled", true);
    $("#txtCodigoInterno").val(mascotas[pos].codigoInterno);
    $("#txtCodigo").val(mascotas[pos].codigo);
    $("#txtNombre").val(mascotas[pos].nombre);
    $("#txtRaza").val(mascotas[pos].raza);
    $("#txtEspecie").val(mascotas[pos].especie);
    $("#txtFechaNac").val(mascotas[pos].fechaNac);
    $("#txtFechaLlegada").val(mascotas[pos].fechaLlegada);
    $("#txtPrecioCompra").val(mascotas[pos].precio);
    $("#txtExistencias").val(mascotas[pos].existencias);
    $("#chkMascotaActiva").prop("disabled", false);
    var estatus = mascotas[pos].estatus;
    if (estatus === true) {
        chkMascotaActiva.checked = true;

    } else {
        chkMascotaActiva.checked = false;
    }

    $("#contDinamico").html
            (
                    '<button id="btnEditMascota" type="button" class="btn btn-primary" data-dismiss="modal" onclick="guardarEditMascota(' + pos + ');">Guardar</button>'
                    );
}

function guardarEditMascota(pos)
{
    alerta();
    mascotas[pos].codigoInterno = $("#txtCodigoInterno").val();
    mascotas[pos].codigo = $("#txtCodigo").val();
    mascotas[pos].nombre = $("#txtNombre").val();
    mascotas[pos].raza = $("#txtRaza").val();
    mascotas[pos].especie = $("#txtEspecie").val();
    mascotas[pos].fechaNac = $("#txtFechaNac").val();
    mascotas[pos].fechaLlegada = $("#txtFechaLlegada").val();
    mascotas[pos].precio = $("#txtPrecioCompra").val();
    mascotas[pos].existencias = $("#txtExistencias").val();
    if (chkMascotaActiva.checked === true) {
        mascotas[pos].estatus = true;

    } else {
        mascotas[pos].estatus = false;
    }
    mostrarTablaMascotas();
}

function alerta()
{
    Swal.fire({
        icon: 'success',
        title: 'Hecho',
        text: 'Guardado Exitosamente!'
    });
}
var mercancia =
        [
            {
                codigo_interno: "1",
                codigo_barra: Math.floor(Math.random() * 100000000000),
                nombre: "Correa de Perro",
                marca: 'DOGGYCAN',
                modelo: 'XLXM',
                descripcion: 'Correa para perros de tamaño grande',
                precioCompra: 150,

                existencias: 6,
                estatus: true
            },
            {
                codigo_interno: "2",
                codigo_barra: Math.floor(Math.random() * 100000000000),
                nombre: "Talco antipulgas",
                marca: 'Bayer',
                modelo: 'pt14',
                descripcion: 'Talco antipulgas para todas las mascotas 150gr.',
                precioCompra: 60,

                existencias: 17,
                estatus: true
            },
            {
                codigo_interno: "3",
                codigo_barra: Math.floor(Math.random() * 100000000000),
                nombre: "Collar antipulgas",
                marca: 'Harzt',
                modelo: 'HT2-1',
                descripcion: 'Collar antipulgas para perro y gato',
                precioCompra: 220,

                existencias: 3,
                estatus: true
            },
            {
                codigo_interno: "4",
                codigo_barra: Math.floor(Math.random() * 100000000000),
                nombre: "Enjuague bucal",
                marca: 'Golden Dog',
                modelo: 'GD-2',
                descripcion: 'Enjuage bucal antisarro 500ml. para mascota',
                precioCompra: 88,

                existencias: 23,
                estatus: true
            },
            {
                codigo_interno: "5",
                codigo_barra: Math.floor(Math.random() * 100000000000),
                nombre: "Croquetas para perro",
                marca: 'DogShow',
                modelo: 'CD-H',
                descripcion: 'Croquetas de DogShow para perros razas pequeñas 1kg.',
                precioCompra: 102,

                existencias: 50,
                estatus: true
            }
        ];

function alerta() {
    Swal.fire
            ({
                icon: 'success',
                title: 'Hecho',
                text: 'Guardado Exitosamente!'
            });
}


function mostrarTablaMercancia() {
    $("#btnAdd").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < mercancia.length; i++) {
        if (mercancia[i].estatus === true) {
            contenido +=
                    '<tr id="Mercancia' + i + '">' +
                    '<td id="codigo_interno' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                    '<td id="codigo_Producto' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                    '<td id="codigo_barra' + i + '">' + mercancia[i].codigo_barra + '</td>' +
                    '<td id="nombre' + i + '">' + mercancia[i].nombre + '</td>' +
                    '<td id="marca' + i + '">' + mercancia[i].marca + '</td>' +
                    '<td id="modelo' + i + '">' + mercancia[i].modelo + '</td>' +
                    '<td id="descripcion' + i + '">' + mercancia[i].descripcion + '</td>' +
                    '<td id="precioCompra' + i + '">' + '$' + mercancia[i].precioCompra + '</td>' +
                    '<td id="precioVenta' + i + '">' + '$' + (mercancia[i].precioCompra * 2) + '</td>' +
                    '<td id="existencias' + i + '">' + mercancia[i].existencias + '</td>' +
                    '<td id="estatus' + i + '">' + (mercancia[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editMercancia(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteMercancia(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        } else {
            contenido +=
                    '<tr id="Mercancia' + i + '">' +
                    '<td id="codigo_interno' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                    '<td id="codigo_Producto' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                    '<td id="codigo_barra' + i + '">' + mercancia[i].codigo_barra + '</td>' +
                    '<td id="nombre' + i + '">' + mercancia[i].nombre + '</td>' +
                    '<td id="marca' + i + '">' + mercancia[i].marca + '</td>' +
                    '<td id="modelo' + i + '">' + mercancia[i].modelo + '</td>' +
                    '<td id="descripcion' + i + '">' + mercancia[i].descripcion + '</td>' +
                    '<td id="precioCompra' + i + '">' + '$' + mercancia[i].precioCompra + '</td>' +
                    '<td id="precioVenta' + i + '">' + '$' + (mercancia[i].precioCompra * 2) + '</td>' +
                    '<td id="existencias' + i + '">' + mercancia[i].existencias + '</td>' +
                    '<td id="estatus' + i + '">' + (mercancia[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editMercancia(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-success" onclick="activarMercancia(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        }
    }
    $("#tbodyMercancia").html(contenido);
    
    
}


function mostraralagregaroelimerc() {

    $("#btnAddProv").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < mercancia.length; i++)
    {
        if (mercancia[i].estatus === true) {
            contenido +=
                    '<tr id="Mercancia' + i + '">' +
                    '<td id="codigo_interno' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                    '<td id="codigo_Producto' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                    '<td id="codigo_barra' + i + '">' + mercancia[i].codigo_barra + '</td>' +
                    '<td id="nombre' + i + '">' + mercancia[i].nombre + '</td>' +
                    '<td id="marca' + i + '">' + mercancia[i].marca + '</td>' +
                    '<td id="modelo' + i + '">' + mercancia[i].modelo + '</td>' +
                    '<td id="descripcion' + i + '">' + mercancia[i].descripcion + '</td>' +
                    '<td id="precioCompra' + i + '">' + '$' + mercancia[i].precioCompra + '</td>' +
                    '<td id="precioVenta' + i + '">' + '$' + (mercancia[i].precioCompra * 2) + '</td>' +
                    '<td id="existencias' + i + '">' + mercancia[i].existencias + '</td>' +
                    '<td id="estatus' + i + '">' + (mercancia[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editMercancia(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteMercancia(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        }
        $("#tbodyMercancia").html(contenido);


    }
}
function mostrarInactivos(){
     var contenido = '';
     for (var i = 0; i < mercancia.length; i++)
            {
                if (mercancia[i].estatus === false) {
                    contenido +=
                            '<tr id="Mercancia' + i + '">' +
                            '<td id="codigo_interno' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                            '<td id="codigo_Producto' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                            '<td id="codigo_barra' + i + '">' + mercancia[i].codigo_barra + '</td>' +
                            '<td id="nombre' + i + '">' + mercancia[i].nombre + '</td>' +
                            '<td id="marca' + i + '">' + mercancia[i].marca + '</td>' +
                            '<td id="modelo' + i + '">' + mercancia[i].modelo + '</td>' +
                            '<td id="descripcion' + i + '">' + mercancia[i].descripcion + '</td>' +
                            '<td id="precioCompra' + i + '">' + '$' + mercancia[i].precioCompra + '</td>' +
                            '<td id="precioVenta' + i + '">' + '$' + (mercancia[i].precioCompra * 2) + '</td>' +
                            '<td id="existencias' + i + '">' + mercancia[i].existencias + '</td>' +
                            '<td id="estatus' + i + '">' + (mercancia[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editMercancia(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-success" onclick="activarMercancia(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyMercancia").html(contenido);
}

function mostrarActivos(){
     var contenido = '';
     for (var i = 0; i < mercancia.length; i++)
            {
                if (mercancia[i].estatus === true) {
                    contenido +=
                            '<tr id="Mercancia' + i + '">' +
                            '<td id="codigo_interno' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                            '<td id="codigo_Producto' + i + '">' + mercancia[i].codigo_interno + '</td>' +
                            '<td id="codigo_barra' + i + '">' + mercancia[i].codigo_barra + '</td>' +
                            '<td id="nombre' + i + '">' + mercancia[i].nombre + '</td>' +
                            '<td id="marca' + i + '">' + mercancia[i].marca + '</td>' +
                            '<td id="modelo' + i + '">' + mercancia[i].modelo + '</td>' +
                            '<td id="descripcion' + i + '">' + mercancia[i].descripcion + '</td>' +
                            '<td id="precioCompra' + i + '">' + '$' + mercancia[i].precioCompra + '</td>' +
                            '<td id="precioVenta' + i + '">' + '$' + (mercancia[i].precioCompra * 2) + '</td>' +
                            '<td id="existencias' + i + '">' + mercancia[i].existencias + '</td>' +
                            '<td id="estatus' + i + '">' + (mercancia[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editMercancia(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-danger"  onclick="deleteMercancia(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyMercancia").html(contenido);               
}
    


function filtrarMerc() {
    var optFiltro = parseInt($("#selectFiltro").val());
   
    switch (optFiltro) {
        case 0:
            mostrarTablaMercancia();
            break;
        case 1:
            mostrarInactivos();
            break;
        case 2:
            mostrarActivos();
            break;
    }    
}

function deleteMercancia(pos)
{
    if (mercancia[pos].estatus === true) {
        mercancia[pos].estatus = false;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Mercancia eliminada de forma logica exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' esta mercancia ya esta eliminado logicamente!'
        });
        mostraralagregaroelimerc();
    }
    mostrarTablaMercancia();
}

function activarMercancia(pos) {
    if (mercancia[pos].estatus === false) {
        mercancia[pos].estatus = true;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Mercancia activada exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' esta mercancia ya esta activada!'
        });
        mostrarTablaMercancia();
    }
    mostrarTablaMercancia();
}

$("#btnAdd").click(function ()
{
    $("#exampleModalLabel").addClass("text-success");
    $("#exampleModalLabel").removeClass("text-warning");
    $("#exampleModalLabel").html("Agregar Mercancia");
    $("#btnEditMercancia").hide();
    $("#btnAddMercancia").show();
    $("#txtCodigoBarras").val(null);
    $("#txtCodigoInterno").val(mercancia.length + 1);
    $("#txtCodigoProducto").val( mercancia.length + 1);
    $("#txtNombre").val(null);
    $("#txtCodigoProducto").prop("disabled", true);
    $("#txtCodigoInterno").prop("disabled", true);
    $("#txtMarca").val(null);
    $("#txtModelo").val(null);
    $("#txtDescripcion").val(null);
    $("#txtPrecioCompra").val(null);
    $("#txtPrecioVenta").val(null);
    $("#txtExistencias").val(null);
    $("#chkMercanciaActiva").prop("checked", true);
    $("#chkMercanciaActiva").prop("disabled", true);
});

function confirmarNuevaMercancia() {
    mercancia.push
            (
                    {
                        codigo_barra: $("#txtCodigoBarras").val(),
                        codigo_interno: $("#txtCodigoInterno").val(),                       
                        nombre: $("#txtNombre").val(),
                        marca: $("#txtMarca").val(),
                        modelo: $("#txtModelo").val(),
                        descripcion: $("#txtDescripcion").val(),
                        precioCompra: $("#txtPrecioCompra").val(),
                        existencias: $("#txtExistencias").val(),
                        estatus: true
                    }

            );                           
    alerta();
    mostraralagregaroelimerc();
}

function editMercancia(pos)
{
    $("#exampleModalLabel").html("Editar Mercancia");
    $("#exampleModalLabel").removeClass("text-success");
    $("#exampleModalLabel").addClass("text-warning");
    $("#btnEditMercancia").show();
    $("#btnAddMercancia").hide();
    $("#txtCodigoProducto").prop("disabled", true);  
    $("#txtCodigoInterno").prop("disabled", true);
    $("#txtNombre").prop("disabled", false);
    $("#txtCodigoBarras").val(mercancia[pos].codigo_barra);
    $("#txtCodigoInterno").val(mercancia[pos].codigo_interno);
    $("#txtCodigoProducto").val(mercancia[pos].codigo_interno);
    $("#txtNombre").val(mercancia[pos].nombre);
    $("#txtMarca").val(mercancia[pos].marca);
    $("#txtModelo").val(mercancia[pos].modelo);
    $("#txtDescripcion").val(mercancia[pos].descripcion);
    $("#txtPrecioCompra").val(mercancia[pos].precioCompra);
    $("#txtPrecioVenta").val(mercancia[pos].precioCompra * 2);
    $("#txtExistencias").val(mercancia[pos].existencias);
    $("#chkMercanciaActiva").prop("disabled", true);
    chkMercanciaActiva.checked = true;

    
     

    $("#contDinamico").html
            (
                    '<button id="btnEditMercancia" type="button" class="btn btn-primary" data-dismiss="modal" onclick="guardarEditMercancia(' + pos + ');">Guardar</button>'
                    );
}

function guardarEditMercancia(pos)
{
    alerta();
    mercancia[pos].codigo_interno = $("#txtCodigoInterno").val();
    mercancia[pos].codigo_barra = $("#txtCodigoBarras").val();
    mercancia[pos].nombre = $("#txtNombre").val();
    mercancia[pos].marca = $("#txtMarca").val();
    mercancia[pos].modelo = $("#txtModelo").val();
    mercancia[pos].descripcion = $("#txtDescripcion").val();
    mercancia[pos].precioCompra = $("#txtPrecioCompra").val();
    mercancia[pos].existencias = $("#txtExistencias").val();
    $("#chkMercanciaActiva").prop("disabled", false);
    if (chkMercanciaActiva.checked === true) {
        mercancia[pos].estatus = true;
    } else {
        clientes[pos].estatus = false;
    }
    alerta();
    mostrarTablaMercancia();
}

function alerta()
{
    Swal.fire({
        icon: 'success',
        title: 'Hecho',
        text: 'Guardado Exitosamente!'
    });
}
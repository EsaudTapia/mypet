var proveedores =
        [
            {
                codigoInterno: 1,
                razonSocial: "Malvados y Asociados",
                RFC: "MVAS110502",
                nombre: "Inocencio",
                aPaterno: "Baños",
                aMaterno: "Muñoz",
                telefono: 4774619713,
                calle: "Martires de almoloya",
                numero: "S/N",
                colonia: "Santa Rita",
                CP: 57420,
                estatus: true
            },
            {
                codigoInterno: 2,
                razonSocial: "Monsters Inc",
                RFC: "MSIN451267",
                nombre: "Sulivan",
                aPaterno: "Jaime",
                aMaterno: "Perez",
                telefono: 4772720942,
                calle: "Sustos",
                numero: "150-A",
                colonia: "Randall",
                CP: 44901,
                estatus: true
            },
            {
                codigoInterno: 3,
                razonSocial: "Silver Mask",
                RFC: "SVMK170520",
                nombre: "Rey",
                aPaterno: "Barrientos",
                aMaterno: "Misterio",
                telefono: 4774619713,
                calle: "Pancracio",
                numero: 619,
                colonia: "Dr. Wagner",
                CP: 60319,
                estatus: true
            },
            {
                codigoInterno: 4,
                razonSocial: "Kan Hijo",
                RFC: "KNHJ201099",
                nombre: "Jose Joaquin",
                aPaterno: "Aquino",
                aMaterno: "Maz",
                telefono: 4778681259,
                calle: "Plata Nito",
                numero: "810-C",
                colonia: "Industrial Tepito",
                CP: 14508,
                estatus: true
            },
            {
                codigoInterno: 5,
                razonSocial: "Capsule Corp",
                RFC: "CSCR301219",
                nombre: "Goku",
                aPaterno: "Sayajin",
                aMaterno: "Tres",
                telefono: 4779841033,
                calle: "Kamisama",
                numero: "150-F",
                colonia: "Broli",
                CP: 35221,
                estatus: true
            }
        ];

function mostrarTablaProveedores() {
    $("#btnAddProv").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < proveedores.length; i++)
    {
        if (proveedores[i].estatus === true) {
            contenido +=
                    '<tr id="proveedor' + i + '">' +
                    '<td id="codigoInterno' + i + '">' + proveedores[i].codigoInterno + '</td>' +
                    '<td id="razonSocial' + i + '">' + proveedores[i].razonSocial + '</td>' +
                    '<td id="RFC' + i + '">' + proveedores[i].RFC + '</td>' +
                    '<td id="nombre' + i + '">' + proveedores[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + proveedores[i].aPaterno + '</td>' +
                    '<td id="aMaterno' + i + '">' + proveedores[i].aMaterno + '</td>' +
                    '<td id="telefono' + i + '">' + proveedores[i].telefono + '</td>' +
                    '<td id="direccion' + i + '">' + proveedores[i].calle + " #" + proveedores[i].numero + ", " + proveedores[i].colonia + ". " + proveedores[i].CP + '</td>' +
                    '<td id="estatus' + i + '">' + (proveedores[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editProveedor(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteProveedor(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        } else {
            contenido +=
                    '<tr id="proveedor' + i + '">' +
                    '<td id="codigoInterno' + i + '">' + proveedores[i].codigoInterno + '</td>' +
                    '<td id="razonSocial' + i + '">' + proveedores[i].razonSocial + '</td>' +
                    '<td id="RFC' + i + '">' + proveedores[i].RFC + '</td>' +
                    '<td id="nombre' + i + '">' + proveedores[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + proveedores[i].aPaterno + '</td>' +
                    '<td id="aMaterno' + i + '">' + proveedores[i].aMaterno + '</td>' +
                    '<td id="telefono' + i + '">' + proveedores[i].telefono + '</td>' +
                    '<td id="direccion' + i + '">' + proveedores[i].calle + " #" + proveedores[i].numero + ", " + proveedores[i].colonia + ". " + proveedores[i].CP + '</td>' +
                    '<td id="estatus' + i + '">' + (proveedores[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editProveedor(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-success" onclick="activarProveedor(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
        }
    }
    $("#tbodyProveedores").html(contenido);
}

function mostraralagregaroeliprov(){
    
     $("#btnAddProv").prop("disabled", false);
    var contenido = '';
    for (var i = 0; i < proveedores.length; i++)
    {
        if (proveedores[i].estatus === true) {
            contenido +=
                    '<tr id="proveedor' + i + '">' +
                    '<td id="codigoInterno' + i + '">' + proveedores[i].codigoInterno + '</td>' +
                    '<td id="razonSocial' + i + '">' + proveedores[i].razonSocial + '</td>' +
                    '<td id="RFC' + i + '">' + proveedores[i].RFC + '</td>' +
                    '<td id="nombre' + i + '">' + proveedores[i].nombre + '</td>' +
                    '<td id="aPaterno' + i + '">' + proveedores[i].aPaterno + '</td>' +
                    '<td id="aMaterno' + i + '">' + proveedores[i].aMaterno + '</td>' +
                    '<td id="telefono' + i + '">' + proveedores[i].telefono + '</td>' +
                    '<td id="direccion' + i + '">' + proveedores[i].calle + " #" + proveedores[i].numero + ", " + proveedores[i].colonia + ". " + proveedores[i].CP + '</td>' +
                    '<td id="estatus' + i + '">' + (proveedores[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                    '<td>' +
                    '<div class="btn-group">' +
                    '<button class="btn btn-sm btn-warning" onclick="editProveedor(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                    '<button class="btn btn-sm btn-danger"  onclick="deleteProveedor(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                    '</div>' +
                    '</td>' +
                    '</tr>';
             }
    $("#tbodyProveedores").html(contenido);
    
    
}
}

function filtrarProv() {
    var optFiltro = parseInt($("#selectFiltro").val());
    var contenido = '';
    switch (optFiltro) {
        case 0:
            mostrarTablaProveedores();
        break;
        case 1:
            for (var i = 0; i < proveedores.length; i++)
            {
                if (proveedores[i].estatus === false) {
                    contenido +=
                            '<tr id="proveedor' + i + '">' +
                            '<td id="codigoInterno' + i + '">' + proveedores[i].codigoInterno + '</td>' +
                            '<td id="razonSocial' + i + '">' + proveedores[i].razonSocial + '</td>' +
                            '<td id="RFC' + i + '">' + proveedores[i].RFC + '</td>' +
                            '<td id="nombre' + i + '">' + proveedores[i].nombre + '</td>' +
                            '<td id="aPaterno' + i + '">' + proveedores[i].aPaterno + '</td>' +
                            '<td id="aMaterno' + i + '">' + proveedores[i].aMaterno + '</td>' +
                            '<td id="telefono' + i + '">' + proveedores[i].telefono + '</td>' +
                            '<td id="direccion' + i + '">' + proveedores[i].calle + " #" + proveedores[i].numero + ", " + proveedores[i].colonia + ". " + proveedores[i].CP + '</td>' +
                            '<td id="estatus' + i + '">' + (proveedores[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editProveedor(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-success" onclick="activarProveedor(' + i + ');"><i class="fal fa-plus"></i> Activar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyProveedores").html(contenido);
            break;
        case 2:
            for (var i = 0; i < proveedores.length; i++)
            {
                if (proveedores[i].estatus === true) {
                    contenido +=
                            '<tr id="proveedor' + i + '">' +
                            '<td id="codigoInterno' + i + '">' + proveedores[i].codigoInterno + '</td>' +
                            '<td id="razonSocial' + i + '">' + proveedores[i].razonSocial + '</td>' +
                            '<td id="RFC' + i + '">' + proveedores[i].RFC + '</td>' +
                            '<td id="nombre' + i + '">' + proveedores[i].nombre + '</td>' +
                            '<td id="aPaterno' + i + '">' + proveedores[i].aPaterno + '</td>' +
                            '<td id="aMaterno' + i + '">' + proveedores[i].aMaterno + '</td>' +
                            '<td id="telefono' + i + '">' + proveedores[i].telefono + '</td>' +
                            '<td id="direccion' + i + '">' + proveedores[i].calle + " #" + proveedores[i].numero + ", " + proveedores[i].colonia + ". " + proveedores[i].CP + '</td>' +
                            '<td id="estatus' + i + '">' + (proveedores[i].estatus ? '<i class="fal fa-check-square"></i>' : '<i class="fal fa-square"></i>') + '</td>' +
                            '<td>' +
                            '<div class="btn-group">' +
                            '<button class="btn btn-sm btn-warning" onclick="editProveedor(' + i + ');" data-toggle="modal" data-target="#exampleModal"><i class="fal fa-edit"></i> Editar</button>' +
                            '<button class="btn btn-sm btn-danger"  onclick="deleteProveedor(' + i + ');"><i class="fal fa-trash-alt"></i> Eliminar</button>' +
                            '</div>' +
                            '</td>' +
                            '</tr>';
                }
            }
            $("#tbodyProveedores").html(contenido);
            break;
    }
}


function deleteProveedor(pos)
{
    if (proveedores[pos].estatus === true) {
        proveedores[pos].estatus = false;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Proveedor eliminado de forma logica exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' este proveedor ya esta eliminado logicamente!'
        });
        mostrarTablaProveedores();
    }
    mostraralagregaroeliprov();
}

function activarProveedor(pos) {
    if (proveedores[pos].estatus === false) {
        proveedores[pos].estatus = true;
        Swal.fire({
            icon: 'success',
            title: 'Hecho',
            text: 'Proveedor activado exitosamente!'
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'No realizado',
            text: ' este proveedor ya esta agregado!'
        });
        mostrarTablaProveedores();
    }
    filtrarProv();
}

$("#btnAddProv").click(function ()
{
    $("#exampleModalLabel").addClass("text-success");
    $("#exampleModalLabel").removeClass("text-warning");
    $("#exampleModalLabel").html("Agregar Proveedor");
    $("#btnEditProveedor").hide();
    $("#btnAddProveedor").show();
    $("#txtCodigoInterno").prop("disabled", true);
    $("#txtCodigoInterno").val(proveedores.length + 1);
    $("#txtRazonSocial").val(null);
    $("#txtRFC").val(null);
    $("#txtNombre").val(null);
    $("#txtApellidoP").val(null);
    $("#txtApellidoM").val(null);
    $("#txtTel").val(null);
    $("#txtCalle").val(null);
    $("#txtNumero").val(null);
    $("#txtColonia").val(null);
    $("#txtCP").val(null);
    $("#chkProveedorActivo").prop("checked", true);
    $("#chkProveedorActivo").prop("disabled", true);
});

function editProveedor(pos)
{
    $("#exampleModalLabel").html("Editar Proveedor");
    $("#exampleModalLabel").removeClass("text-success");
    $("#exampleModalLabel").addClass("text-warning");
    $("#btnEditProveedor").show();
    $("#btnAddProveedor").hide();
    $("#txtCodigoInterno").val(proveedores[pos].codigoInterno);
    $("#txtRazonSocial").val(proveedores[pos].razonSocial);
    $("#txtRFC").val(proveedores[pos].RFC);
    $("#txtNombre").val(proveedores[pos].nombre);
    $("#txtApellidoP").val(proveedores[pos].aPaterno);
    $("#txtApellidoM").val(proveedores[pos].aMaterno);
    $("#txtTel").val(proveedores[pos].telefono);
    $("#txtCalle").val(proveedores[pos].calle);
    $("#txtNumero").val(proveedores[pos].numero);
    $("#txtColonia").val(proveedores[pos].colonia);
    $("#txtCP").val(proveedores[pos].CP);
    $("#chkProveedorActivo").prop("disabled", false);
    $("#chkProveedorActivo").val(proveedores[pos].estatus);
    if (proveedores[pos].estatus === true) {
        chkProveedorActivo.checked = true;
    } else {
        chkProveedorActivo.checked = false;
    }

    $("#contDinamico").html
            (
                    '<button id="btnEditProveedor" type="button" class="btn btn-primary" data-dismiss="modal" onclick="guardarEditProveedor(' + pos + ');">Guardar</button>'
                    );
}

function guardarEditProveedor(pos)
{
    alerta();
    proveedores[pos].codigoInterno = $("#txtCodigoInterno").val();
    proveedores[pos].razonSocial = $("#txtRazonSocial").val();
    proveedores[pos].RFC = $("#txtRFC").val();
    proveedores[pos].nombre = $("#txtNombre").val();
    proveedores[pos].aPaterno = $("#txtApellidoP").val();
    proveedores[pos].aMaterno = $("#txtApellidoM").val();
    proveedores[pos].telefono = $("#txtTel").val();
    proveedores[pos].calle = $("#txtCalle").val();
    proveedores[pos].numero = $("#txtNumero").val();
    proveedores[pos].colonia = $("#txtColonia").val();
    proveedores[pos].CP = $("#txtCP").val();
    $("chkProveedorActivo").prop("disabled", false);
    if (chkProveedorActivo.checked === true) {
        proveedores[pos].estatus = true;
    } else {
        proveedores[pos].estatus = false;
    }
    mostrarTablaProveedores();
}

function alerta()
{
    Swal.fire({
        icon: 'success',
        title: 'Hecho',
        text: 'Guardado Exitosamente!'
    });
}

function confirmarNuevoProveedor()
{
    proveedores.push
            (
                    {

                        codigoInterno: $("#txtCodigoInterno").val(),
                        razonSocial: $("#txtRazonSocial").val(),
                        RFC: $("#txtRFC").val(),
                        nombre: $("#txtNombre").val(),
                        aPaterno: $("#txtApellidoP").val(),
                        aMaterno: $("#txtApellidoM").val(),
                        telefono: $("#txtTel").val(),
                        calle: $("#txtCalle").val(),
                        numero: $("#txtNumero").val(),
                        colonia: $("#txtColonia").val(),
                        CP: $("#txtCP").val(),
                        estatus: true
                    }
            );
   mostraralagregaroeliprov();
}